package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import com.example.demo.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.models.Compra;
import com.example.demo.repositories.CompraRepository;

@Service
public class CompraService {

    @Autowired
    private CompraRepository compraRepository;

    @Autowired
    private UserService userService; 

    @Transactional
    public Compra create(Compra compra) {
        compra.setId(null);
        return compraRepository.save(compra);
    }

    @Transactional
    public Compra update(Compra compra) {
        Compra existingCompra = buscarCompraPeloId(compra.getId());

        existingCompra.setData(compra.getData());
        existingCompra.setStatus(compra.getStatus());
        existingCompra.setUsuarioComprador(compra.getUsuarioComprador());
        existingCompra.setUsuarioVendedor(compra.getUsuarioVendedor());
        

        return compraRepository.save(existingCompra);
    }

    public Compra buscarCompraPeloId(Long id) {
        Optional<Compra> compra = compraRepository.findById(id);

        return compra.orElseThrow(() -> new RuntimeException(
                "Não foi possível encontrar esta Compra: " + id + " do Tipo: " + Compra.class.getName()
        ));
    }

    public List<Compra> findPeloCompradorId(Long id) {
        User user = userService.buscarPeloIdUser(id);

        return user.getComprasComoComprador();
    }

    public List<Compra> findPeloVendedorId(Long id) {
        User user = userService.buscarPeloIdUser(id);

        return user.getComprasComoVendedor();
    }

    public void delete(Long id) {
        Compra compra = buscarCompraPeloId(id);

        try {
            compraRepository.delete(compra);
        } catch (Exception e) {
            throw new RuntimeException("Não foi possível deletar a compra: " + id);
        }
    }


}