package com.example.demo.controllers;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.support.ServletUriComponentsBuilder;


import com.example.demo.models.Ingresso;

import com.example.demo.services.IngressoService;

import jakarta.validation.Valid;




@RestController
@RequestMapping("/ingresso")
@Validated
public class IngressoController {

    @Autowired
    private IngressoService ingressoService;

    @GetMapping("/{id}")
    public ResponseEntity<Ingresso> buscarPeloId(@PathVariable Long id) {
        Ingresso obj = this.ingressoService.buscarIngressoPeloId(id);
        return ResponseEntity.ok().body(obj);
    }


    @PostMapping
    @Validated
    public ResponseEntity<Ingresso> create(@Valid @RequestBody Ingresso obj) {
        this.ingressoService.create(obj);

        URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(obj.getId()).toUri();

        return ResponseEntity.created(uri).build();
    }

    @PutMapping("/{id}")
    @Validated
    public ResponseEntity<Void> update(@Valid @RequestBody Ingresso obj, @PathVariable Long id) {
        obj.setId(id);

        this.ingressoService.update(obj);

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        this.ingressoService.delete(id);

        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/mudarStatus")
    @Validated
    public ResponseEntity<Void> mudarStatus(@Valid @RequestBody Ingresso obj, @PathVariable Long id){
        Ingresso ingresso = this.ingressoService.buscarIngressoPeloId(id);

        ingresso.setStatus(obj.getStatus());

        this.ingressoService.update(obj);

        return ResponseEntity.noContent().build();

    }
}