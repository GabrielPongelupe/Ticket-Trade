package com.example.demo.models;

public enum StatusCompra {
    NAO_PAGO,
    PAGAMENTO_RETIDO,
    PAGAMENTO_EFETUADO
}

