package com.example.demo.models;

public enum IngressoStatus {
    NAO_VALIDO,
    EM_COMPRA,
    VALIDADO,
    COMPRADO

}