package com.example.demo.Model;

@Entity
public class Ingresso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private User seller;

    private boolean validated;
    private boolean titularidadeChanged; // Variável que indica se a titularidade foi alterada

    
}