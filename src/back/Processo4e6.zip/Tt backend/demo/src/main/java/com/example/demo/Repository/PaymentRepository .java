@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
}