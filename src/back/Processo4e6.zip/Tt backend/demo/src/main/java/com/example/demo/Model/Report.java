package com.example.demo.Model;

@Entity
public class Report {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private User reportedUser;

    @ManyToOne
    private User reportingUser;

    @Column(length = 240)
    private String message;

    // getters and setters
}

