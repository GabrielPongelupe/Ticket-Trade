package com.example.demo.Model;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private User buyer;

    @ManyToOne
    private User seller;

    private BigDecimal amount;

    private boolean confirmedByAdmin;

    
}