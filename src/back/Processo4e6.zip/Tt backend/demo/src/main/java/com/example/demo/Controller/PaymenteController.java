package com.example.demo.Controller;

@RestController
@RequestMapping("/api")
public class PaymentController {

    @Autowired
    private PaymentRepository paymentRepository;

    // Rota para o administrador relatar o pagamento e confirmar
    @PostMapping("/admin/payments/{paymentId}/report")
    public Payment reportPaymentByAdmin(@PathVariable Long paymentId) {
        Payment payment = paymentRepository.findById(paymentId).orElseThrow(() -> new ResourceNotFoundException("Payment not found with id " + paymentId));

        // Altera a variável confirmedByAdmin para true
        payment.setConfirmedByAdmin(true);

        return paymentRepository.save(payment);
    }

    // Rota para o vendedor relatar o pagamento (bem-sucedido ou não)
    @PostMapping("/vendedor/payments/{paymentId}/report")
    public Payment reportPaymentBySeller(@PathVariable Long paymentId, @RequestBody String message) {
        Payment payment = paymentRepository.findById(paymentId).orElseThrow(() -> new ResourceNotFoundException("Payment not found with id " + paymentId));

        // Implemente a lógica para o vendedor relatar o pagamento
        // Se o pagamento for bem-sucedido, atualize o campo confirmedByAdmin para true
        // Se não for bem-sucedido, o vendedor pode enviar uma mensagem que será revisada pelo administrador

        return paymentRepository.save(payment);
    }
}

