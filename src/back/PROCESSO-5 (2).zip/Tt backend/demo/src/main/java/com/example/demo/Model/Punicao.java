package com.example.demo.Model;

@Entity
public class Punicao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private User punishedUser;

    @Column(length = 240)
    private String message;

    private LocalDateTime startDate;

    private LocalDateTime endDate;

 
}



