package com.example.demo.Repository;

@Repository
public interface ReportRepository extends JpaRepository<Report, Long> {
}


