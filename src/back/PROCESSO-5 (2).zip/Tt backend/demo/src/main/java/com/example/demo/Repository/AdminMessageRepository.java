package com.example.demo.Repository;

@Repository
public interface AdminMessageRepository extends JpaRepository<AdminMessage, Long> {
}
