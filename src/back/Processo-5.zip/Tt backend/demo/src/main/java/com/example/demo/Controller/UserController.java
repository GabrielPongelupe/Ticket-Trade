package com.example.demo.Controller;

@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RatingRepository ratingRepository;

    @Autowired
    private ReportRepository reportRepository;

    @Autowired
    private PunishmentRepository punishmentRepository;

    @Autowired
    private AdminMessageRepository adminMessageRepository;

    // Rota para avaliar um usuário
    @PostMapping("/users/{ratedUserId}/ratings")
    public Rating rateUser(@PathVariable Long ratedUserId, @RequestBody Rating rating) {
        return userRepository.findById(ratedUserId).map(ratedUser -> {
            User ratingUser = getCurrentLoggedInUser(); // Implemente lógica para obter o usuário logado
            rating.setRatedUser(ratedUser);
            rating.setRatingUser(ratingUser);
            return ratingRepository.save(rating);
        }).orElseThrow(() -> new ResourceNotFoundException("User not found with id " + ratedUserId));
    }

    // Rota para denunciar um usuário
    @PostMapping("/users/{reportedUserId}/reports")
    public Report reportUser(@PathVariable Long reportedUserId, @RequestBody Report report) {
        return userRepository.findById(reportedUserId).map(reportedUser -> {
            User reportingUser = getCurrentLoggedInUser(); // Implemente lógica para obter o usuário logado
            report.setReportedUser(reportedUser);
            report.setReportingUser(reportingUser);
            return reportRepository.save(report);
        }).orElseThrow(() -> new ResourceNotFoundException("User not found with id " + reportedUserId));
    }
// Rota para punir um usuário
    @PostMapping("/users/{punishedUserId}/punishments")
    public Punishment punishUser(@PathVariable Long punishedUserId, @RequestBody Punishment punishment) {
        return userRepository.findById(punishedUserId).map(punishedUser -> {
            punishment.setPunishedUser(punishedUser);
            punishment.setStartDate(LocalDateTime.now());
            punishment.setEndDate(LocalDateTime.now().plusWeeks(1)); // Punição de uma semana
            return punishmentRepository.save(punishment);
        }).orElseThrow(() -> new ResourceNotFoundException("User not found with id " + punishedUserId));
    }

    // Rota para enviar uma mensagem para o sistema
    @PostMapping("/admin/messages")
    public AdminMessage sendAdminMessage(@RequestBody AdminMessage adminMessage) {
        // Implemente lógica para verificar se o usuário logado é um administrador
        return adminMessageRepository.save(adminMessage);
    }
}
