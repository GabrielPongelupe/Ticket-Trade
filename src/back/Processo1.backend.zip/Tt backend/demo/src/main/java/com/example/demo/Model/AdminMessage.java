package com.example.demo.Model;

@Entity
public class AdminMessage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private User user;

    @Column(length = 240)
    private String message;

    // getters and setters
}

