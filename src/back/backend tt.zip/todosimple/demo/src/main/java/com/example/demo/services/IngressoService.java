package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import com.example.demo.models.Ingresso;
import com.example.demo.models.User;
import com.example.demo.repositories.IngressoRepository;

@Service
public class IngressoService {

    @Autowired
    private IngressoRepository ingressoRepository;

    @Autowired
    private UserService userService;

    public Ingresso buscarIngressoPeloId(Long id) {
        Optional<Ingresso> ingresso = this.ingressoRepository.findById(id);

        return ingresso.orElseThrow(() -> new RuntimeException(
                "Não foi possível encontrar este Ingresso: " + id + " do Tipo: " + Ingresso.class.getName()
        ));
    }

    public List<Ingresso> buscarIngressoPeloUserId(Long id){
        List<Ingresso> ingresso = this.ingressoRepository.findPeloUserID(id);

        return ingresso;
    }

    @Transactional
    public Ingresso create(Ingresso obj) {
        User user = this.userService.buscarPeloIdUser(obj.getUser().getId());

        obj.setId(null);
        obj.setUser(user);
        obj.setStatusPostado();    

        this.ingressoRepository.save(obj);

        return obj;
    }

    @Transactional
    public Ingresso update(Ingresso ingresso) {
        Ingresso obj = this.buscarIngressoPeloId(ingresso.getId());
    
        obj.setDescription(ingresso.getDescription());
        obj.setData(ingresso.getData());
        obj.setStatus(ingresso.getStatus());
        // Adicionar aqui obj.setATRIBUTO() caso inclua novos atributos
    
        return this.ingressoRepository.save(obj);
    }

    public void delete(Long id) {
        Ingresso ingresso = this.buscarIngressoPeloId(id);

        try {
            this.ingressoRepository.delete(ingresso);
        } catch (Exception e) {
            throw new RuntimeException("Não foi possível deletar o ingresso: " + ingresso.getDescription());
        }
    }


}

