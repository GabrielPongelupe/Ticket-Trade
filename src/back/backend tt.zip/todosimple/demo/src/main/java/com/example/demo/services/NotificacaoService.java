package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.models.Notificacao;
import com.example.demo.repositories.NotificacaoRepository;

@Service
public class NotificacaoService {

    @Autowired
    private NotificacaoRepository notificacaoRepository;

    public Notificacao buscarNotificacaoPorId(Long id) {
        Optional<Notificacao> notificacao = this.notificacaoRepository.findById(id);

        return notificacao.orElseThrow(() -> new RuntimeException(
                "Não foi possível encontrar esta Notificação: " + id + " do Tipo: " + Notificacao.class.getName()
        ));
    }

    public List<Notificacao> buscarNotificacoesNaoLidas() {
        List<Notificacao> notificacoes = new ArrayList<>();
        return notificacoes.stream()
            .filter(e -> e.isLida()).collect(Collectors.toList());
    }

    @Transactional
    public Notificacao create(Notificacao notificacao) {
        notificacao.setId(null);
        return notificacaoRepository.save(notificacao);
    }

    @Transactional
    public Notificacao update(Notificacao notificacao) {
        Notificacao existingNotificacao = buscarNotificacaoPorId(notificacao.getId());

        existingNotificacao.setNotificacao(notificacao.getNotificacao());
        existingNotificacao.setData(notificacao.getData());
        existingNotificacao.setLida(notificacao.isLida());

        return notificacaoRepository.save(existingNotificacao);
    }

    public void delete(Long id) {
        Notificacao notificacao = buscarNotificacaoPorId(id);

        try {
            notificacaoRepository.delete(notificacao);
        } catch (Exception e) {
            throw new RuntimeException("Não foi possível deletar a notificação: " + id);
        }
    }
}