package com.example.demo.models;

public enum DenunciaStatus {
    PENDENTE,
    PUNIDO,
    NAO_PUNIDO
}