package com.example.demo.controllers;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.demo.models.Compra;
import com.example.demo.services.CompraService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/compra")
@Validated
public class CompraController {

    @Autowired
    private CompraService compraService;

    @GetMapping("/{id}")
    public ResponseEntity<Compra> buscarPeloId(@PathVariable Long id) {
        Compra compra = this.compraService.buscarCompraPeloId(id);
        return ResponseEntity.ok().body(compra);
    }

    @GetMapping("/comprador/{id}")
    public ResponseEntity<List<Compra>> findPeloCompradorId(@PathVariable Long id) {
        List<Compra> compras = this.compraService.findPeloCompradorId(id);
        return ResponseEntity.ok().body(compras);
    }

    @GetMapping("/vendedor/{id}")
    public ResponseEntity<List<Compra>> findPeloVendedorId(@PathVariable Long id) {
        List<Compra> compras = this.compraService.findPeloVendedorId(id);
        return ResponseEntity.ok().body(compras);
    }

    @PostMapping
    @Validated
    public ResponseEntity<Compra> create(@Valid @RequestBody Compra compra) {
        this.compraService.create(compra);

        URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(compra.getId()).toUri();

        return ResponseEntity.created(uri).build();
    }

    @PutMapping("/{id}")
    @Validated
    public ResponseEntity<Void> update(@Valid @RequestBody Compra compra, @PathVariable Long id) {
        compra.setId(id);

        this.compraService.update(compra);

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        this.compraService.delete(id);

        return ResponseEntity.noContent().build();
    }
}