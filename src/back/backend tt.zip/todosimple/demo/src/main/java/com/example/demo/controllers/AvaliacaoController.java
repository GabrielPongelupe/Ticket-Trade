package com.example.demo.controllers;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.demo.models.Avaliacao;
import com.example.demo.services.AvaliacaoService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/avaliacao")
@Validated
public class AvaliacaoController {

    @Autowired
    private AvaliacaoService avaliacaoService;

    @GetMapping("/{id}")
    public ResponseEntity<Avaliacao> buscarPeloId(@PathVariable Long id) {
        Avaliacao avaliacao = this.avaliacaoService.encontrarAvaliacaoPorId(id);
        return ResponseEntity.ok().body(avaliacao);
    }

    @GetMapping("/usuario/{id}")
    public ResponseEntity<List<Avaliacao>> buscarAvaliacoesDoUsuario(@PathVariable Long id) {
        List<Avaliacao> avaliacoes = this.avaliacaoService.buscarAvaliacoesDoUsuario(id);
        return ResponseEntity.ok().body(avaliacoes);
    }

    @PostMapping
    @Validated
    public ResponseEntity<Avaliacao> create(@Valid @RequestBody Avaliacao avaliacao) {
        this.avaliacaoService.create(avaliacao);

        URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(avaliacao.getAvaliacaoId()).toUri();

        return ResponseEntity.created(uri).build();
    }

    @PutMapping("/{id}")
    @Validated
    public ResponseEntity<Void> update(@Valid @RequestBody Avaliacao avaliacao, @PathVariable Long id) {
        avaliacao.setAvaliacaoId(id);

        this.avaliacaoService.update(avaliacao);

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        this.avaliacaoService.delete(id);

        return ResponseEntity.noContent().build();
    }
}