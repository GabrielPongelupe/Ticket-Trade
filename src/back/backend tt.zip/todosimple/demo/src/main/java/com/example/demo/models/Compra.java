package com.example.demo.models;


import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Table(name = "compra")
@Entity
public class Compra {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "data", nullable = false)
    @NotNull
    private LocalDate data;

    @Column(name = "status", nullable = false)
    @Enumerated(EnumType.STRING)
    private StatusCompra status;

    @ManyToOne
    @JoinColumn(name = "usuario_comprador_id",  nullable = false, updatable = false)
    private User comprador;

    @ManyToOne
    @JoinColumn(name = "usuario_vendedor_id",  nullable = false, updatable = false)
    private User vendedor;

    

    public Compra() {
        // Construtor padrão
    }

    public Compra(LocalDate data, StatusCompra status, User usuarioComprador, User usuarioVendedor) {
        this.data = data;
        this.status = status;
        this.comprador = usuarioComprador;
        this.vendedor = usuarioVendedor;
       
    }

    // Getters e Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public StatusCompra getStatus() {
        return status;
    }

    public void setStatus(StatusCompra status) {
        this.status = status;
    }

    public User getUsuarioComprador() {
        return comprador;
    }

    public void setUsuarioComprador(User usuarioComprador) {
        this.comprador = usuarioComprador;
    }

    public User getUsuarioVendedor() {
        return vendedor;
    }

    public void setUsuarioVendedor(User usuarioVendedor) {
        this.vendedor = usuarioVendedor;
    }

    
}