package com.example.demo.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.models.User;
// import java.util.List;




@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // User findByUsername(String username); NAO APLICADO POIS OS findBy DESSES ATRIBUTOS PADRAO JA ESTAO
        // IMPLEMENTADOS NO JpaRepository

    Optional<User> findByUsername(String username);

    @Query("SELECT u FROM User u WHERE u.username = :username AND u.password = :password")
    User efetuarLogin(@Param("username") String username, @Param("password") String password);

    
}
