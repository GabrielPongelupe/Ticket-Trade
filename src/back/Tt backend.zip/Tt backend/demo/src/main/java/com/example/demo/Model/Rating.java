package com.example.demo.Model;

@Entity
public class Rating {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private User ratedUser;

    @ManyToOne
    private User ratingUser;

    private int stars;

    @Column(length = 240)
    private String message;

    // adicionar outros metodos
}

