package com.example.demo.Repository;

@Repository
public interface IngressoRepository extends JpaRepository<Ingresso, Long> {

}
