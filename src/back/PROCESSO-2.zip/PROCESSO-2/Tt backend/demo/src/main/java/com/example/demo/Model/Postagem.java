package com.example.demo.Model;

@Entity
public class Postagem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titulo;

    @Column(nullable = false, length = 240)
    private String descricao;

    @ManyToOne
    private User user;

    // Getters e setters
}
