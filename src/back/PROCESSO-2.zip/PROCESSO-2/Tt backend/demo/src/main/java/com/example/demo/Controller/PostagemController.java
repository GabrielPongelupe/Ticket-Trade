package com.example.demo.Controller;

@RestController
@RequestMapping("/api")
public class PostagemController {

    @Autowired
    private PostagemRepository postagemRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/users/{userId}/postagens")
    public Postagem cadastrarPostagem(@PathVariable Long userId, @RequestBody Postagem postagem) {
        return userRepository.findById(userId).map(user -> {
            postagem.setUser(user);
            return postagemRepository.save(postagem);
        }).orElseThrow(() -> new ResourceNotFoundException("User not found with id " + userId));
    }

    @GetMapping("/users/{userId}/postagens")
    public List<Postagem> getPostagensByUserId(@PathVariable Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + userId));
        return postagemRepository.findByUser(user);
    }

    @PutMapping("/users/{userId}/postagens/{postId}")
    public Postagem editarPostagem(@PathVariable Long userId, @PathVariable Long postId, @RequestBody Postagem postagemAtualizada) {
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User not found with id " + userId);
        }

        return postagemRepository.findById(postId).map(postagem -> {
            postagem.setTitulo(postagemAtualizada.getTitulo());
            postagem.setDescricao(postagemAtualizada.getDescricao());
    
            return postagemRepository.save(postagem);
        }).orElseThrow(() -> new ResourceNotFoundException("Postagem not found with id " + postId));
    }

    @DeleteMapping("/users/{userId}/postagens/{postId}")
    public ResponseEntity<?> excluirPostagem(@PathVariable Long userId, @PathVariable Long postId) {
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User not found with id " + userId);
        }

        return postagemRepository.findByIdAndUserId(postId, userId).map(postagem -> {
            postagemRepository.delete(postagem);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Postagem not found with id " + postId + " for User with id " + userId));
    }
}
