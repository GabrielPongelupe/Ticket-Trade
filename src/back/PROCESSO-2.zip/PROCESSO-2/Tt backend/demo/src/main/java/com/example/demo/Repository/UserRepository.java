package com.example.demo.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
}