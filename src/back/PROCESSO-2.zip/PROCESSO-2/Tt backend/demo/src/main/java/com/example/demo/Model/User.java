package com.example.demo.Model;


@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    // Outros campos, getters e setters
}
