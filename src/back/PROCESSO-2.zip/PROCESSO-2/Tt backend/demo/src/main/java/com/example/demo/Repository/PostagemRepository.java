package com.example.demo.Repository;

@Repository
public interface PostagemRepository extends JpaRepository<Postagem, Long> {
    List<Postagem> findByUser(User user);
}
