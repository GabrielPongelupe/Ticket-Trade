package com.example.demo.Repository;
@Repository
public interface ImagemIngressoRepository extends JpaRepository<ImagemIngresso, Long> {
}
