package com.example.demo.Model;

@Entity
public class ImagemIngresso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob
    @Column(nullable = false)
    private byte[] imagem;

    // Getters e setters
}



