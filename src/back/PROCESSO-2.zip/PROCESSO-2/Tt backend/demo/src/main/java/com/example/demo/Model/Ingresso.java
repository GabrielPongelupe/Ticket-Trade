package com.example.demo.Model;

@Entity
public class Ingresso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nomeEvento;

    @Column(nullable = false)
    private String cidade;

    @Column(nullable = false)
    private LocalDate data;

    @Column(nullable = false)
    private double preco;

    @Column(length = 240, nullable = false)
    private String descricao;

    // Getters e setters
}

