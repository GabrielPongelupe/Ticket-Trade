document.addEventListener('DOMContentLoaded', function() {
    var today = new Date().toISOString().split('T')[0];
    document.getElementById('dataInput').setAttribute('min', today);
});



document.getElementById('valorInput').addEventListener('input', function(event) {
    let valor = event.target.value;

    // Remove todos os caracteres que não são números ou a vírgula
    valor = valor.replace(/[^\d,]/g, '');

    // Garante que haja apenas uma vírgula
    let partes = valor.split(',');
    if (partes.length > 2) {
        partes = [partes.shift(), partes.join('')];
    }

    // Adiciona ponto a cada três dígitos antes da vírgula ou em todos os grupos de três dígitos se não houver vírgula
    let parteInteira = partes[0] || '';
    parteInteira = parteInteira.replace(/\d{1,3}(?=(\d{3})+(?!\d))/g, '$&.');

    // Atualiza o valor no campo
    event.target.value = 'R$ ' + (parteInteira) + (partes.length > 1 ? ',' + partes[1] : '');
});



document.addEventListener('DOMContentLoaded', function() {
    var descricaoInput = document.querySelector('input[name="descricao"]');
    var descricaoError = document.getElementById('descricaoError');

    descricaoInput.addEventListener('input', function() {
        var descricaoLength = this.value.length;
        var maxLength = 240;

        if (descricaoLength > maxLength) {
            descricaoError.innerText = 'Limite de 240 caracteres excedido';
        } else {
            descricaoError.innerText = '';
        }
    });
});





