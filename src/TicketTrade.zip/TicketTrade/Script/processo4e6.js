function closePopup(){
    document.getElementById('popup').style.display = "none";
    document.getElementById('overlay').style.display = "none";

}


function clicou(){
    
    document.getElementById('icone').style.display = "none";
    document.getElementById('retangulo').style.display = "block";

}

function saiu(){
    
    document.getElementById('icone').style.display = "block";
    document.getElementById('retangulo').style.display = "none";
}
