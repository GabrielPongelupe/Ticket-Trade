// processo2.js

// Sample data for demonstration
var eventData = [
    { nomeEvento: "Evento 1", data: "2023-01-01", valor: "$50.00" },
    { nomeEvento: "Evento 2", data: "2023-02-15", valor: "$30.00" },
    // Add more event data as needed
];

// Function to populate the table with data
function populateTable() {
    var table = document.getElementById("tabelaIngressos");

    // Clear existing rows
    table.innerHTML = "<tr><th>Evento</th><th>Nome Evento</th><th>Data</th><th>Valor</th><th>Página Do Ingresso</th></tr>";

    // Populate table with data
    for (var i = 0; i < eventData.length; i++) {
        var row = table.insertRow(-1);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        var cell4 = row.insertCell(3);
        var cell5 = row.insertCell(4);

        cell1.innerHTML = '<img src="Imagens/RogerW.jpeg" alt="Imagem do Evento">';
        cell2.innerHTML = eventData[i].nomeEvento;
        cell3.innerHTML = eventData[i].data;
        cell4.innerHTML = eventData[i].valor;
        cell5.innerHTML = '<a href="PaginaIngresso.html" class="botaoEstilizado" id="' + (i + 1) + '">Ver Mais</a>';
    }
}

// Function to filter the table based on search input
function filterTable() {
    var input = document.getElementById("nomeEventoInput").value.toUpperCase();
    var table = document.getElementById("tabelaIngressos");
    var rows = table.getElementsByTagName("tr");

    for (var i = 0; i < rows.length; i++) {
        var cells = rows[i].getElementsByTagName("td")[1]; // Index 1 is the column with Nome Evento

        if (cells) {
            var textValue = cells.textContent || cells.innerText;

            if (textValue.toUpperCase().indexOf(input) > -1) {
                rows[i].style.display = "";
            } else {
                rows[i].style.display = "none";
            }
        }
    }
}
