
const endpoint = "texto.json";

fetch(endpoint)
    .then(res => res.text()) 
    .then(res => {
        res=JSON.parse(res);
        valores[0] = res.grafico1.Janeiro;
        valores[1] = res.grafico1.Fevereiro;
        valores[2] = res.grafico1.Março;
        valores[3] = res.grafico1.Abril;
        valores[4] = res.grafico1.Maio;
        valores[5] = res.grafico1.Junho; 
        valores[6] = res.grafico1.Julho;
        valores[7] = res.grafico1.Agosto;
        valores[8] = res.grafico1.Setembro;
        valores[9] = res.grafico1.Outubro;
        valores[10] = res.grafico1.Novembro;
        valores[11] = res.grafico1.Dezembro;

        grafico1.update();
    })
    .catch(erro => {
        console.log("ERRO:" + erro);
    });


fetch(endpoint)
    .then(res => res.text()) 
    .then(res => {
        res=JSON.parse(res);
        valoresY[0] = res.grafico2.Janeiro;
        valoresY[1] = res.grafico2.Fevereiro;
        valoresY[2] = res.grafico2.Março;
        valoresY[3] = res.grafico2.Abril;
        valoresY[4] = res.grafico2.Maio;
        valoresY[5] = res.grafico2.Junho; 
        valoresY[6] = res.grafico2.Julho;
        valoresY[7] = res.grafico2.Agosto;
        valoresY[8] = res.grafico2.Setembro;
        valoresY[9] = res.grafico2.Outubro;
        valoresY[10] = res.grafico2.Novembro;
        valoresY[11] = res.grafico2.Dezembro;

        grafico2.update();
    })
    .catch(erro => {
        console.log("ERRO:" + erro);
    });

    fetch(endpoint)
    .then(res => res.text()) 
    .then(res => {
        res=JSON.parse(res);
        valoresZ[0] = res.grafico3.Janeiro;
        valoresZ[1] = res.grafico3.Fevereiro;
        valoresZ[2] = res.grafico3.Março;
        valoresZ[3] = res.grafico3.Abril;
        valoresZ[4] = res.grafico3.Maio;
        valoresZ[5] = res.grafico3.Junho; 
        valoresZ[6] = res.grafico3.Julho;
        valoresZ[7] = res.grafico3.Agosto;
        valoresZ[8] = res.grafico3.Setembro;
        valoresZ[9] = res.grafico3.Outubro;
        valoresZ[10] = res.grafico3.Novembro;
        valoresZ[11] = res.grafico3.Dezembro;

        grafico3.update();
    })
    .catch(erro => {
        console.log("ERRO:" + erro);
    });

    fetch(endpoint)
    .then(res => res.text()) 
    .then(res => {
        res=JSON.parse(res);
        valoresA[0] = res.grafico4.Janeiro;
        valoresA[1] = res.grafico4.Fevereiro;
        valoresA[2] = res.grafico4.Março;
        valoresA[3] = res.grafico4.Abril;
        valoresA[4] = res.grafico4.Maio;
        valoresA[5] = res.grafico4.Junho; 
        valoresA[6] = res.grafico4.Julho;
        valoresA[7] = res.grafico4.Agosto;
        valoresA[8] = res.grafico4.Setembro;
        valoresA[9] = res.grafico4.Outubro;
        valoresA[10] = res.grafico4.Novembro;
        valoresA[11] = res.grafico4.Dezembro;

        grafico4.update();
    })
    .catch(erro => {
        console.log("ERRO:" + erro);
    });

    fetch(endpoint)
    .then(res => res.text()) 
    .then(res => {
        res=JSON.parse(res);
        valoresF[0] = res.grafico5.Janeiro;
        valoresF[1] = res.grafico5.Fevereiro;
        valoresF[2] = res.grafico5.Março;
        valoresF[3] = res.grafico5.Abril;
        valoresF[4] = res.grafico5.Maio;
        valoresF[5] = res.grafico5.Junho; 
        valoresF[6] = res.grafico5.Julho;
        valoresF[7] = res.grafico5.Agosto;
        valoresF[8] = res.grafico5.Setembro;
        valoresF[9] = res.grafico5.Outubro;
        valoresF[10] = res.grafico5.Novembro;
        valoresF[11] = res.grafico5.Dezembro;

        grafico5.update();
    })
    .catch(erro => {
        console.log("ERRO:" + erro);
    });

    fetch(endpoint)
    .then(res => res.text()) 
    .then(res => {
        res=JSON.parse(res);
        valoresR[0] = res.grafico6.Janeiro;
        valoresR[1] = res.grafico6.Fevereiro;
        valoresR[2] = res.grafico6.Março;
        valoresR[3] = res.grafico6.Abril;
        valoresR[4] = res.grafico6.Maio;
        valoresR[5] = res.grafico6.Junho; 
        valoresR[6] = res.grafico6.Julho;
        valoresR[7] = res.grafico6.Agosto;
        valoresR[8] = res.grafico6.Setembro;
        valoresR[9] = res.grafico6.Outubro;
        valoresR[10] = res.grafico6.Novembro;
        valoresR[11] = res.grafico6.Dezembro;

        grafico6.update();
    })
    .catch(erro => {
        console.log("ERRO:" + erro);
    });

