// Tela Cadastro Ingresso
// Requerir o modelo de Ingresso
const Ingresso = require('./models/Ingresso');

// Rota para lidar com a submissão do formulário
router.post('/cadastrar-ingresso', async (req, res) => {
    try {
        const { nomeEvento, Cidade, data, valor, descricao, imagem, usuarioId } = req.body;

        // Inserir os dados na tabela INGRESSO
        const novoIngresso = await Ingresso.create({
            nomeEvento,
            Cidade,
            data,
            preco: valor,
            descricao,
            imagem,
            USUARIO_ID: usuarioId // Associar o USUARIO_ID ao usuário que está cadastrando o ingresso
        });

        res.status(201).json({ message: 'Ingresso cadastrado com sucesso!' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ocorreu um erro ao cadastrar o ingresso.' });
    }
});

module.exports = router;



