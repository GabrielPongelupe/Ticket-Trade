const express = require('express');
const router = express.Router();

// Requerir o modelo de Ingresso
const Ingresso = require('./models/Ingresso');

// Rota para buscar ingressos com base nos critérios preenchidos no formulário
router.post('/buscar-ingressos', async (req, res) => {
    try {
        const { nomeEvento, Cidade, data } = req.body;

        // Construir a consulta com base nos critérios preenchidos
        const query = {};
        if (nomeEvento) query.nomeEvento = nomeEvento;
        if (Cidade) query.Cidade = Cidade;
        if (data) query.data = data;

        // Consulta no banco de dados
        const ingressosEncontrados = await Ingresso.find(query);

        res.json(ingressosEncontrados);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ocorreu um erro ao buscar os ingressos.' });
    }
});

module.exports = router;
