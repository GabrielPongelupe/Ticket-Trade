const express = require('express');
const router = express.Router();

// Requerir o modelo de Ingresso
const Ingresso = require('./models/Ingresso');

// Rota para acessar a página do ingresso
router.get('/ingresso/:id', async (req, res) => {
    try {
        const id = req.params.id;

        // Consulta no banco de dados para obter os detalhes do ingresso
        const ingresso = await Ingresso.findById(id);

        if (!ingresso) {
            return res.status(404).json({ message: 'Ingresso não encontrado.' });
        }

        res.json(ingresso);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ocorreu um erro ao acessar a página do ingresso.' });
    }
});

module.exports = router;
